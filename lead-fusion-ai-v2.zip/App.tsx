
import React, { useState } from 'react';
import { Lead } from './types';
import { generateLeads } from './services/geminiService';
import LeadForm from './components/LeadForm';
import LeadTable from './components/LeadTable';
import { DownloadIcon, WebhookIcon } from './components/Icons';

const App: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('restaurants');
  const [city, setCity] = useState('New York');
  const [country, setCountry] = useState('USA');
  const [numLeads, setNumLeads] = useState(10);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progressMessage, setProgressMessage] = useState('');
  const [webhookUrl, setWebhookUrl] = useState('');
  const [webhookStatus, setWebhookStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setLeads([]);
    setProgressMessage('Initializing lead generation... This may take a moment.');

    try {
      const generatedLeads = await generateLeads(searchQuery, city, country, numLeads);
      setLeads(generatedLeads);

      if (generatedLeads.length === 0) {
        setError("No businesses found. Try different search terms.");
        setProgressMessage('');
      } else if (generatedLeads.length < numLeads) {
        setProgressMessage(`Found ${generatedLeads.length} leads (requested ${numLeads}).`);
      } else {
        setProgressMessage(`Successfully generated ${generatedLeads.length} leads!`);
      }

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      setProgressMessage('');
    } finally {
      setIsLoading(false);
    }
  };

  const downloadJson = () => {
    if (leads.length === 0) return;
    const exportData = { leads: leads };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `leads_${searchQuery}_${city}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const sendToWebhook = async () => {
    if (leads.length === 0 || !webhookUrl) return;
    setWebhookStatus('sending');
    const exportData = { leads: leads };
    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(exportData),
      });
      if (!response.ok) {
        throw new Error(`Webhook failed with status: ${response.status}`);
      }
      setWebhookStatus('success');
    } catch (error) {
      setWebhookStatus('error');
      console.error('Webhook error:', error);
    } finally {
      setTimeout(() => setWebhookStatus('idle'), 3000);
    }
  };

  const getWebhookButtonClass = () => {
    switch (webhookStatus) {
        case 'sending': return 'bg-yellow-500';
        case 'success': return 'bg-green-500';
        case 'error': return 'bg-red-500';
        default: return 'bg-slate-600 hover:bg-slate-700';
    }
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500">
            Lead Fusion AI
          </h1>
          <p className="mt-2 text-lg text-slate-400">Generate High-Quality Business Leads with AI</p>
        </header>

        <main>
          <LeadForm
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            city={city}
            setCity={setCity}
            country={country}
            setCountry={setCountry}
            numLeads={numLeads}
            setNumLeads={setNumLeads}
            isLoading={isLoading}
            onSubmit={handleSubmit}
          />

          {(isLoading || error || leads.length > 0) && (
            <div className="mt-8 bg-slate-800 p-6 rounded-xl shadow-lg">
              <h2 className="text-2xl font-bold mb-4 text-white">Results</h2>
              {isLoading && <p className="text-indigo-400 animate-pulse">{progressMessage}</p>}
              {error && <p className="text-red-400 bg-red-900/50 p-3 rounded-md">{error}</p>}
              
              {leads.length > 0 && !isLoading && (
                <>
                  <p className="text-green-400 mb-4">{progressMessage}</p>
                  <div className="flex flex-col sm:flex-row gap-4 mb-4 items-start sm:items-center">
                    <button onClick={downloadJson} className="flex items-center justify-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-md transition-colors w-full sm:w-auto">
                      <DownloadIcon /> Download JSON
                    </button>
                    <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto sm:items-center">
                        <label htmlFor='webhookUrl' className="text-sm font-medium text-slate-300 sr-only">Webhook URL (optional)</label>
                        <input 
                            id="webhookUrl"
                            type="url" 
                            placeholder="Webhook URL (optional)"
                            value={webhookUrl}
                            onChange={(e) => setWebhookUrl(e.target.value)}
                            className="w-full sm:w-64 bg-slate-700 border border-slate-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        <button onClick={sendToWebhook} disabled={!webhookUrl || webhookStatus !== 'idle'} className={`flex items-center justify-center px-4 py-2 text-white font-semibold rounded-md shadow-md transition-colors w-full sm:w-auto disabled:opacity-50 disabled:cursor-not-allowed ${getWebhookButtonClass()}`}>
                          <WebhookIcon /> 
                          {webhookStatus === 'sending' && 'Sending...'}
                          {webhookStatus === 'success' && 'Sent!'}
                          {webhookStatus === 'error' && 'Error!'}
                          {webhookStatus === 'idle' && 'Send to Webhook'}
                        </button>
                    </div>
                  </div>
                  <LeadTable leads={leads} />
                </>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default App;
