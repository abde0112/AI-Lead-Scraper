
import { GoogleGenAI } from "@google/genai";
import { Lead } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateLeads = async (
  searchQuery: string,
  city: string,
  country: string,
  numLeads: number
): Promise<Lead[]> => {
  const prompt = `
    Act as a lead generation expert. Your task is to find exactly ${numLeads} business leads for "${searchQuery}" in ${city}, ${country} using Google Maps.
    
    For each business found, extract ALL available information.
    
    OUTPUT FORMAT:
    Return a JSON object with this exact structure:

    {
      "leads": [
        {
          "GeneratedDate": "YYYY-MM-DD",
          "SearchCity": "${city}",
          "SearchCountry": "${country}",
          "LeadNumber": number,
          "CompanyName": "business name",
          "Category": "business category",
          "Description": "description",
          "Address": "full address",
          "City": "city",
          "Country": "country",
          "Coordinates": "lat,lng",
          "MapLink": "https://www.google.com/maps/search/?api=1&query=...",
          "Phone": "phone number",
          "Email": "email or empty string",
          "Website": "website URL or empty string",
          "LinkedIn": "LinkedIn URL or empty string",
          "Facebook": "Facebook URL or empty string",
          "Instagram": "Instagram URL or empty string",
          "Rating": 4.5,
          "ReviewCount": 1234,
          "BusinessHours": "hours string",
          "QualityScore": 50,
          "QualityReasoning": "reasoning",
          "Status": "New",
          "Contacted": "No",
          "Notes": ""
        }
      ]
    }

    IMPORTANT GUIDELINES:
    1. "MapLink" must be a valid Google Maps search URL using the Company Name and Address.
       Format: https://www.google.com/maps/search/?api=1&query=[CompanyName]+[FullAddress] (replace spaces with +).
    2. "Rating" and "ReviewCount" are critical.
    3. "QualityScore" (0-100) calculation:
       - Has phone: +20 points
       - Has email: +10 points
       - Has website: +15 points
       - Has social media: +10 points
       - Rating > 4.0: +15 points
       - ReviewCount > 100: +15 points
       - Complete business hours: +15 points
    4. Website: Extract complete URL. If none found, use empty string "". Do not use "N/A" or "-".
    5. Return EXACTLY ${numLeads} leads.
    6. Do not include any markdown formatting (like \`\`\`json). Just the raw JSON string.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleMaps: {} }],
      },
    });

    let jsonText = response.text.trim();
    
    // The model might still wrap the JSON in markdown. Strip it if present.
    if (jsonText.startsWith('```json')) {
      jsonText = jsonText.substring(7);
      if (jsonText.endsWith('```')) {
        jsonText = jsonText.slice(0, -3);
      }
    } else if (jsonText.startsWith('```')) {
      jsonText = jsonText.substring(3);
       if (jsonText.endsWith('```')) {
        jsonText = jsonText.slice(0, -3);
      }
    }
    
    const result = JSON.parse(jsonText);
    
    if (!result || !Array.isArray(result.leads)) {
        throw new Error("API did not return a valid object with a 'leads' array.");
    }

    return result.leads;
  } catch (error) {
    console.error("Error generating leads:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
    throw new Error(`Failed to generate leads. ${errorMessage}`);
  }
};
