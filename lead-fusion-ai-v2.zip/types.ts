
export interface Lead {
  GeneratedDate: string;
  SearchCity: string;
  SearchCountry: string;
  LeadNumber: number;
  CompanyName: string;
  Category: string;
  Description: string;
  Address: string;
  City: string;
  Country: string;
  Coordinates: string;
  MapLink: string;
  Phone: string;
  Email: string;
  Website: string;
  LinkedIn: string;
  Facebook: string;
  Instagram: string;
  Rating: number;
  ReviewCount: number;
  BusinessHours: string;
  QualityScore: number;
  QualityReasoning: string;
  Status: "New";
  Contacted: "No";
  Notes: string;
}
