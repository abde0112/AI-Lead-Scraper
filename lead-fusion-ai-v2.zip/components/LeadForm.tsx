
import React, { useState, useRef, useEffect } from 'react';
import { SpinnerIcon } from './Icons';

interface LeadFormProps {
  searchQuery: string;
  setSearchQuery: (value: string) => void;
  city: string;
  setCity: (value: string) => void;
  country: string;
  setCountry: (value: string) => void;
  numLeads: number;
  setNumLeads: (value: number) => void;
  isLoading: boolean;
  onSubmit: (e: React.FormEvent) => void;
}

// Data arrays for autocomplete
const businessTypes = [
  "Restaurant", "Cafe", "Coffee Shop", "Bakery", "Bar", "Pub",
  "Plumber", "Electrician", "Carpenter", "Painter", "Handyman",
  "Dentist", "Doctor", "Clinic", "Hospital", "Pharmacy",
  "Lawyer", "Attorney", "Legal Services",
  "Marketing Agency", "Advertising Agency", "Digital Marketing",
  "Gym", "Fitness Center", "Yoga Studio", "Spa", "Salon",
  "Hair Salon", "Barber Shop", "Beauty Salon",
  "Real Estate Agent", "Property Management",
  "Accountant", "Bookkeeper", "Tax Consultant",
  "Web Designer", "Software Developer", "IT Services",
  "Photographer", "Videographer", "Event Planner",
  "Florist", "Garden Center", "Landscaping"
];

const cities = [
  "Casablanca", "Casa Grande", "Rabat", "Marrakech", "Tangier",
  "New York", "Los Angeles", "Chicago", "Houston", "Phoenix",
  "London", "Manchester", "Birmingham", "Liverpool",
  "Paris", "Lyon", "Marseille", "Toulouse",
  "Tokyo", "Osaka", "Kyoto",
  "Dubai", "Abu Dhabi",
  "Sydney", "Melbourne", "Brisbane",
  "Toronto", "Vancouver", "Montreal",
  "Berlin", "Munich", "Hamburg",
  "Madrid", "Barcelona", "Valencia",
  "Rome", "Milan", "Naples",
  "Amsterdam", "Rotterdam"
];

const countries = [
  "Morocco", "USA", "United States", "UK", "United Kingdom",
  "France", "Germany", "Spain", "Italy", "Canada",
  "Australia", "Japan", "UAE", "Netherlands", "Portugal",
  "Belgium", "Switzerland", "Austria", "Sweden", "Norway"
];

const AutocompleteInput = ({ 
  label, 
  id, 
  value, 
  onChange, 
  placeholder, 
  suggestions 
}: { 
  label: string, 
  id: string, 
  value: string, 
  onChange: (val: string) => void, 
  placeholder: string, 
  suggestions: string[] 
}) => {
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filteredSuggestions, setFilteredSuggestions] = useState<string[]>([]);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [wrapperRef]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const userInput = e.target.value;
    onChange(userInput);

    if (userInput.length >= 2) {
      const filtered = suggestions.filter(
        (item) => item.toLowerCase().startsWith(userInput.toLowerCase())
      );
      setFilteredSuggestions(filtered);
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };

  const handleSelectSuggestion = (suggestion: string) => {
    onChange(suggestion);
    setShowSuggestions(false);
  };

  return (
    <div className="relative" ref={wrapperRef}>
      <label htmlFor={id} className="block text-sm font-medium text-slate-300 mb-1">{label}</label>
      <input
        id={id}
        type="text"
        value={value}
        onChange={handleInputChange}
        onFocus={() => {
            if (value.length >= 2) {
                const filtered = suggestions.filter(
                    (item) => item.toLowerCase().startsWith(value.toLowerCase())
                );
                setFilteredSuggestions(filtered);
                setShowSuggestions(true);
            }
        }}
        placeholder={placeholder}
        className="w-full bg-slate-700 border border-slate-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
        required
        autoComplete="off"
      />
      {showSuggestions && filteredSuggestions.length > 0 && (
        <ul className="absolute z-10 w-full bg-slate-700 border border-slate-600 mt-1 max-h-60 overflow-auto rounded-md shadow-lg">
          {filteredSuggestions.map((suggestion, index) => (
            <li
              key={index}
              onClick={() => handleSelectSuggestion(suggestion)}
              className="px-4 py-2 hover:bg-indigo-600 cursor-pointer text-slate-200"
            >
              {suggestion}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};


const LeadForm: React.FC<LeadFormProps> = ({
  searchQuery, setSearchQuery, city, setCity, country, setCountry,
  numLeads, setNumLeads, isLoading, onSubmit
}) => {
  
  return (
    <form onSubmit={onSubmit} className="bg-slate-800 p-6 rounded-xl shadow-lg space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <AutocompleteInput
            label="Business Type"
            id="searchQuery"
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="e.g., Restaurant, Plumber"
            suggestions={businessTypes}
        />
        <AutocompleteInput
            label="City"
            id="city"
            value={city}
            onChange={setCity}
            placeholder="e.g., Casablanca, New York"
            suggestions={cities}
        />
        <AutocompleteInput
            label="Country"
            id="country"
            value={country}
            onChange={setCountry}
            placeholder="e.g., Morocco, USA"
            suggestions={countries}
        />
        <div>
          <label htmlFor="numLeads" className="block text-sm font-medium text-slate-300 mb-1">Number of Leads</label>
          <div className="relative">
            <input
                id="numLeads"
                type="number"
                min="1"
                max="100"
                value={numLeads}
                onChange={(e) => {
                    const val = parseInt(e.target.value);
                    if (!isNaN(val)) setNumLeads(Math.min(100, Math.max(1, val)));
                }}
                className="w-full bg-slate-700 border border-slate-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <p className="text-xs text-slate-500 mt-1">Min: 1, Max: 100</p>
        </div>
      </div>
      <div className="pt-2">
        <button
          type="submit"
          disabled={isLoading}
          className="w-full flex justify-center items-center bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-bold py-3 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-indigo-500 transition-colors duration-200 shadow-lg transform active:scale-[0.99]"
        >
          {isLoading ? <><SpinnerIcon /> Generating...</> : 'Generate Leads'}
        </button>
      </div>
    </form>
  );
};

export default LeadForm;
