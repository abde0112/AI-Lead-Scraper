
import React from 'react';
import { Lead } from '../types';

interface LeadTableProps {
  leads: Lead[];
}

const LeadTable: React.FC<LeadTableProps> = ({ leads }) => {
  if (leads.length === 0) {
    return null;
  }

  return (
    <div className="overflow-x-auto bg-slate-800 rounded-lg shadow-lg mt-5">
      <table className="w-full border-collapse text-left">
        <thead className="bg-slate-900 text-slate-400 text-xs font-semibold uppercase tracking-wide">
          <tr>
            <th className="p-3 border-b border-slate-700">LEAD #</th>
            <th className="p-3 border-b border-slate-700">COMPANY NAME</th>
            <th className="p-3 border-b border-slate-700">CATEGORY</th>
            <th className="p-3 border-b border-slate-700">RATING</th>
            <th className="p-3 border-b border-slate-700">REVIEWS</th>
            <th className="p-3 border-b border-slate-700">PHONE</th>
            <th className="p-3 border-b border-slate-700">WEBSITE</th>
            <th className="p-3 border-b border-slate-700">MAP</th>
          </tr>
        </thead>
        <tbody className="text-slate-300 text-sm">
          {leads.map((lead, index) => (
            <tr key={index} className="hover:bg-slate-700 border-b border-slate-700 last:border-0 transition-colors duration-150">
              <td className="p-3 font-semibold text-amber-400">{lead.LeadNumber}</td>
              <td className="p-3 text-slate-50 text-[15px]"><strong>{lead.CompanyName}</strong></td>
              <td className="p-3 text-slate-400 text-[13px]">{lead.Category}</td>
              <td className="p-3">
                {lead.Rating > 0 ? (
                  <span className="inline-block bg-amber-400 text-black px-3 py-1 rounded-2xl font-semibold text-sm">
                    ⭐ {lead.Rating}
                  </span>
                ) : (
                   <span className="text-slate-500">-</span>
                )}
              </td>
              <td className="p-3">
                <span className="text-slate-400 text-[13px]">
                  {lead.ReviewCount > 0 ? `${lead.ReviewCount} reviews` : '-'}
                </span>
              </td>
              <td className="p-3">
                {lead.Phone ? (
                    <a href={`tel:${lead.Phone}`} className="text-blue-400 hover:text-blue-500 hover:underline font-medium">
                    {lead.Phone}
                    </a>
                ) : '-'}
              </td>
              <td className="p-3">
                {lead.Website && lead.Website !== '-' && lead.Website !== '' ? (
                  <a 
                    href={lead.Website} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="inline-block px-3 py-1.5 bg-blue-500 hover:bg-blue-600 text-white no-underline rounded-md text-[13px] font-medium transition-colors"
                  >
                    🔗 Visit
                  </a>
                ) : (
                  <span>-</span>
                )}
              </td>
              <td className="p-3">
                {lead.MapLink && lead.MapLink !== '-' && lead.MapLink !== '' ? (
                  <a 
                    href={lead.MapLink} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="inline-block px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white no-underline rounded-md text-[13px] font-medium transition-colors"
                  >
                    📍 View on Maps
                  </a>
                ) : (
                  <span>-</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default LeadTable;
